module com.example.wapi {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.json;


    opens com.example.wapi to javafx.fxml;
    exports com.example.wapi;
}