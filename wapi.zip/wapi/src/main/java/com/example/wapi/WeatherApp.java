package com.example.wapi;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.json.JSONObject;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class WeatherApp extends Application {
    private static final String API_KEY = "3bf4334cd21c77a55ac7eb3ce601961c";
    private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&lang=pl&units=metric";

    private Label weatherLabel, tempLabel, visibilityLabel, windLabel, rainLabel, snowLabel, cloudsLabel, cityLabel;
    private ImageView weatherIcon;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("API Pogody");

        TextField cityInput = new TextField();
        cityInput.setPromptText("Wpisz nazwę miasta");

        ImageView searchIcon = new ImageView(new Image("https://cdn-icons-png.flaticon.com/512/622/622669.png"));
        searchIcon.setFitWidth(20);
        searchIcon.setFitHeight(20);

        Button searchButton = new Button();
        searchButton.setGraphic(searchIcon);

        weatherLabel = new Label();
        tempLabel = new Label();
        visibilityLabel = new Label();
        windLabel = new Label();
        rainLabel = new Label();
        snowLabel = new Label();
        cloudsLabel = new Label();
        cityLabel = new Label();
        weatherIcon = new ImageView();

        searchButton.setOnAction(e -> fetchWeather(cityInput.getText()));

        VBox root = new VBox(10, cityInput, searchButton, weatherIcon, weatherLabel, tempLabel, visibilityLabel, windLabel, rainLabel, snowLabel, cloudsLabel, cityLabel);
        root.setPadding(new Insets(15));

        Scene scene = new Scene(root, 350, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void fetchWeather(String city) {
        try {
            String urlString = String.format(API_URL, city, API_KEY);
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStreamReader reader = new InputStreamReader(conn.getInputStream());
            Scanner scanner = new Scanner(reader);
            StringBuilder response = new StringBuilder();
            while (scanner.hasNext()) {
                response.append(scanner.nextLine());
            }
            scanner.close();

            JSONObject json = new JSONObject(response.toString());
            String weatherDesc = json.getJSONArray("weather").getJSONObject(0).getString("description");
            String iconCode = json.getJSONArray("weather").getJSONObject(0).getString("icon");
            double temp = json.getJSONObject("main").getDouble("temp");
            int visibility = json.has("visibility") ? json.getInt("visibility") : -1;
            double windSpeed = json.getJSONObject("wind").getDouble("speed");
            String rain = json.has("rain") ? json.getJSONObject("rain").toString() : "Brak opadów";
            String snow = json.has("snow") ? json.getJSONObject("snow").toString() : "Brak śniegu";
            int clouds = json.getJSONObject("clouds").getInt("all");
            String cityName = json.getString("name");

            weatherLabel.setText("Pogoda: " + weatherDesc);
            tempLabel.setText("Temperatura: " + temp + "°C");
            visibilityLabel.setText("Widoczność: " + (visibility >= 0 ? visibility + "m" : "Brak danych"));
            windLabel.setText("Wiatr: " + windSpeed + " m/s");
            rainLabel.setText("Opady deszczu: " + rain);
            snowLabel.setText("Opady śniegu: " + snow);
            cloudsLabel.setText("Zachmurzenie: " + clouds + "%");
            cityLabel.setText("Miasto: " + cityName);
            weatherIcon.setImage(new Image("http://openweathermap.org/img/w/" + iconCode + ".png"));
        } catch (Exception e) {
            weatherLabel.setText("Błąd pobierania danych");
        }
    }
}
