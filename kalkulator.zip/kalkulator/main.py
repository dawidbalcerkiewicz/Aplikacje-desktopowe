import tkinter as tk
import unittest
import main

root = tk.Tk()
root.geometry("300x300")

def klik():
    try:
        liczba1 = int(entry1.get())
        liczba2 = int(entry2.get())
        suma = liczba1 + liczba2
        wynik.config(text=str(suma))
    except ValueError:
        wynik.config(text="Błąd!")

tk.Label(root, text="liczba1").grid(row=0, column=0)
tk.Label(root, text="liczba2").grid(row=1, column=0)

entry1 = tk.Entry(root)
entry1.grid(row=0, column=1)

entry2 = tk.Entry(root)
entry2.grid(row=1, column=1)

btn = tk.Button(root, text="oblicz", command=klik)
btn.grid(row=2, column=0, columnspan=2)

wynik = tk.Label(root, text="....")
wynik.grid(row=3, column=0, columnspan=2)

if __name__=="__main__":
    root.mainloop()

import unittest
import tkinter as tk
import main

class TestKalkulatorTkinter(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.root = main.root
        cls.entry1 = main.entry1
        cls.entry2 = main.entry2
        cls.wynik = main.wynik

    def setUp(self):
        self.entry1.delete(0, tk.END)
        self.entry2.delete(0, tk.END)
        self.wynik.config(text="")

    # Test 1: 5 + 10 = 15
    def test_poprawne_dodawanie(self):
        self.entry1.insert(0, "5")
        self.entry2.insert(0, "10")

        main.klik()   # ⬅⬅⬅ TUTAJ ZMIANA

        self.assertEqual(self.wynik.cget("text"), "15")

    # Test 2: "abc" + "5"
    def test_bledne_dane(self):
        self.entry1.insert(0, "abc")
        self.entry2.insert(0, "5")

        main.klik()

        self.assertEqual(self.wynik.cget("text"), "Błąd!")

    # Test 3: puste pola
    def test_puste_pola(self):
        main.klik()
        self.assertEqual(self.wynik.cget("text"), "Błąd!")


if __name__ == "__main__":
    unittest.main()

